<?php include('header.php');?>
<div>
<?php 

echo "<h1>Amader terms nai bhai</h1>";

?>
</div>
<?php include('footer.php');?>


